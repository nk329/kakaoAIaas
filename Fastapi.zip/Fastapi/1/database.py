from models import MenuItem, Order

menu_db = [
    MenuItem(id=1, name="아메리카노", price=3000),
    MenuItem(id=2, name="카페라떼", price=3500),
    MenuItem(id=3, name="카푸치노", price=4000),
]

order_db = [] 